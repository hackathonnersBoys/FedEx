import React, { useEffect, useState } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';

const WarehouseDashboard  = () => {
  const [activeTab, setActiveTab] = useState('incoming'); // Tab state: 'incoming' or 'outgoing'
  const [warehouseId, setWarehouseId] = useState(''); // User-specified warehouse ID
  const [trucks, setTrucks] = useState([]);
  const [error, setError] = useState(null);
  const [map, setMap] = useState(null); // MapLibre instance
  const [selectedTruck, setSelectedTruck] = useState(null); // Selected truck for route display

  useEffect(() => {
    if (!warehouseId) return;

    // Determine the API endpoint based on the active tab and warehouseId
    const endpoint =
      activeTab === 'incoming'
        ? `/api/getIncomingLiveTrucks?warehouseId=${warehouseId}`
        : `/api/getOutgoingTrucks?warehouseId=${warehouseId}`;

    // Fetch data from the API
    fetch(endpoint)
      .then((response) => {
        if (!response.ok) {
          throw new Error(`Error: ${response.status}`);
        }
        return response.json();
      })
      .then((data) => {
        setTrucks(data.incomingTrucks || data.outgoing_trucks || []);
      })
      .catch((err) => {
        setError(err.message);
      });
  }, [activeTab, warehouseId]); // Re-fetch data when the active tab or warehouseId changes

  useEffect(() => {
    // Initialize the MapLibre map
    const mapInstance = new maplibregl.Map({
      container: 'map', // Container ID
      style: 'https://demotiles.maplibre.org/style.json', // Map style URL
      center: [78.9629, 20.5937], // Center of the map (India as an example)
      zoom: 4,
    });

    setMap(mapInstance);

    // Cleanup map instance on component unmount
    return () => mapInstance.remove();
  }, []);

  
  const handleTruckClick = (truck) => {
    setSelectedTruck(truck);
  
    // Fetch the actual ID for the truck
    fetch(`/api/devices/getId?uniqueId=${truck.truck_id}`)
      .then((response) => {
        if (!response.ok) {
          throw new Error(`Error fetching actual ID: ${response.status}`);
        }
        return response.json();
      })
      .then((idData) => {
        console.log(idData);
        const actual_id = idData.id; // Assuming the API returns the actual_id in this field
  
        // Call the API to get geofence details for the truck
        return fetch(`/api/devices/${actual_id}/manage-geofence`);
      })
      .then((response) => {
        if (!response.ok) {
          throw new Error(`Error fetching geofence: ${response.status}`);
        }
        return response.json();
      })
      .then((geofenceData) => {
        const geofenceArea = geofenceData.geofence.area; // Assuming the geofence area is in "area" field
        const routeCoordinates = parseLineString(geofenceArea); // Parse LINESTRING into coordinates
  
        // Calculate the center of the route
        const center = calculateCenter(routeCoordinates);
  
        // Add the route to the map
        if (map) {
          map.flyTo({
            center, // Fly to the center of the route
            zoom: 11,
          });
  
          if (map.getSource('route')) {
            map.getSource('route').setData({
              type: 'Feature',
              geometry: {
                type: 'LineString',
                coordinates: routeCoordinates,
              },
            });
          } else {
            map.addSource('route', {
              type: 'geojson',
              data: {
                type: 'Feature',
                geometry: {
                  type: 'LineString',
                  coordinates: routeCoordinates,
                },
              },
            });
  
            map.addLayer({
              id: 'route',
              type: 'line',
              source: 'route',
              layout: {
                'line-join': 'round',
                'line-cap': 'round',
              },
              paint: {
                'line-color': '#007bff',
                'line-width': 4,
              },
            });
          }
        }
      })
      .catch((err) => {
        console.error('Error:', err);
      });
  };
  
  // Helper function to parse LINESTRING into coordinates
  const parseLineString = (lineString) => {
    // Remove "LINESTRING(" and ")"
    const coordinateString = lineString.replace('LINESTRING(', '').replace(')', '');
    // Split into coordinate pairs
    const pairs = coordinateString.split(',');
    // Convert pairs into [longitude, latitude] arrays
    return pairs.map((pair) => {
      const [lat, lon] = pair.trim().split(' ');
      return [parseFloat(lon), parseFloat(lat)];
    });
  };
  
  // Helper function to calculate the center of a route
  const calculateCenter = (coordinates) => {
    const total = coordinates.reduce(
      (acc, coord) => {
        acc[0] += coord[0]; // Sum of longitudes
        acc[1] += coord[1]; // Sum of latitudes
        return acc;
      },
      [0, 0]
    );
  
    return [total[0] / coordinates.length, total[1] / coordinates.length]; // Average of longitudes and latitudes
  };
  

  return (
    <div style={{ display: 'flex' }}>
      <div style={{ flex: 1, padding: '20px' }}>
        <h1>Truck Dashboard</h1>

        {/* Warehouse ID Input */}
        <div style={{ marginBottom: '20px' }}>
          <label>
            <strong>Warehouse ID:</strong>{' '}
            <input
              type="text"
              value={warehouseId}
              onChange={(e) => setWarehouseId(e.target.value)}
              placeholder="Enter Warehouse ID"
              style={{ padding: '5px', marginRight: '10px' }}
            />
          </label>
          <button
            onClick={() => {
              if (!warehouseId) {
                setError('Please enter a valid warehouse ID.');
                return;
              }
              setError(null);
            }}
            style={{
              padding: '5px 10px',
              backgroundColor: '#007bff',
              color: '#fff',
              border: 'none',
              cursor: 'pointer',
            }}
          >
            Fetch Trucks
          </button>
        </div>

        {/* Tab Navigation */}
        <div style={{ marginBottom: '20px' }}>
          <button
            style={{
              padding: '10px 20px',
              marginRight: '10px',
              backgroundColor: activeTab === 'incoming' ? '#007bff' : '#ccc',
              color: '#fff',
              border: 'none',
              cursor: 'pointer',
            }}
            onClick={() => setActiveTab('incoming')}
          >
            Incoming Trucks
          </button>
          <button
            style={{
              padding: '10px 20px',
              backgroundColor: activeTab === 'outgoing' ? '#007bff' : '#ccc',
              color: '#fff',
              border: 'none',
              cursor: 'pointer',
            }}
            onClick={() => setActiveTab('outgoing')}
          >
            Outgoing Trucks
          </button>
        </div>

        {error ? (
          <p style={{ color: 'red' }}>Error: {error}</p>
        ) : (
          <table border="1" style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th>Truck ID</th>
                <th>Name</th>
                <th>Current Location</th>
                <th>Destination</th>
                <th>Current Location Name</th>
                <th>Destination Name</th>
                <th>Status</th>
                <th>Current Weight (kg)</th>
                <th>Filled Capacity (%)</th>
              </tr>
            </thead>
            <tbody>
              {trucks.length > 0 ? (
                trucks.map((truck) => (
                  <tr
                    key={truck.truck_id}
                    onClick={() => handleTruckClick(truck)} // Handle truck click
                    style={{ cursor: 'pointer' }}
                  >
                    <td>{truck.truck_id}</td>
                    <td>{truck.name}</td>
                    <td>{truck.current_location}</td>
                    <td>{truck.current_destination}</td>
                    <td>{truck.current_location_name}</td>
                    <td>{truck.current_destination_name}</td>
                    <td>{truck.truck_status}</td>
                    <td>{truck.current_weight}</td>
                    <td>{truck.filled_capacity.toFixed(2)}%</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="9" style={{ textAlign: 'center' }}>
                    No {activeTab === 'incoming' ? 'incoming' : 'outgoing'} trucks found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </div>

      {/* Map Container */}
      <div
        id="map"
        style={{
          flex: 1,
          height: '100vh',
          borderLeft: '1px solid #ccc',
        }}
      ></div>
    </div>
  );
};

export default WarehouseDashboard ;
