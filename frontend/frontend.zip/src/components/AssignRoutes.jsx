import React, { useState, useEffect } from 'react';

const AssignRoutes = () => {
  const [trucks, setTrucks] = useState([]);
  const [warehouses, setWarehouses] = useState([]);
  const [selectedTruck, setSelectedTruck] = useState(null);
  const [selectedWarehouses, setSelectedWarehouses] = useState([]);
  const [assignedWarehouses, setAssignedWarehouses] = useState([]);

  // Fetch trucks and warehouses on component mount
  useEffect(() => {
    fetchTrucks();
    fetchWarehouses();
  }, []);

  // Fetch list of trucks
  const fetchTrucks = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/devices'); // Update with your backend URL
      const data = await response.json();
      
      // Extract truck names from the data
      const truckNames = data.map((truck) => ({
        id: truck.id,
        name: truck.name,
        uniqueId: truck.uniqueId, // Optional: You can add more fields if needed
      }));
  
      setTrucks(truckNames); // Set the truck names into state
    } catch (error) {
      console.error('Error fetching trucks:', error);
    }
  };
  

  // Fetch list of warehouses
  const fetchWarehouses = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/geofences'); // Update with your backend URL
      const data = await response.json();
      setWarehouses(data); // Assuming the response contains an array of warehouses
    } catch (error) {
      console.error('Error fetching warehouses:', error);
    }
  };

  // Fetch assigned warehouses for the selected truck
  const fetchAssignedWarehouses = async (truckId) => {
    try {
      const response = await fetch(`http://localhost:3000/api/devices/geofences?uniqueId=${truckId}`);
      const data = await response.json();
      setAssignedWarehouses(data); // Assuming the response contains an array of assigned warehouses
    } catch (error) {
      console.error('Error fetching assigned warehouses:', error);
    }
  };

  // Handle truck selection
  const handleTruckSelect = (event) => {
    const truckId = event.target.value;
    setSelectedTruck(truckId);
    setSelectedWarehouses([]); // Reset selected warehouses when a new truck is selected
    fetchAssignedWarehouses(truckId); // Fetch assigned warehouses for the new truck
  };

  // Handle warehouse selection
  const handleWarehouseSelect = (warehouseId) => {
    setSelectedWarehouses((prevSelected) =>
      prevSelected.includes(warehouseId)
        ? prevSelected.filter((id) => id !== warehouseId) // Remove warehouse if already selected
        : [...prevSelected, warehouseId] // Add warehouse if not selected
    );

  };

  // Assign selected warehouses to the truck
  const handleAssignWarehouses = async () => {
    if (!selectedTruck) {
      alert('Please select a truck first.');
      return;
    }



    try {
        console.log("THE selected trucl ARE ")
        console.log(selectedTruck)
      const response = await fetch(`http://localhost:3000/api/devices/assignRoute`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
            "uniqueId" : selectedTruck,
            warehouseIds: selectedWarehouses 
        }), // Send selected warehouses to the backend
      });

      if (response.ok) {
        alert('Warehouses assigned successfully!');
        fetchAssignedWarehouses(selectedTruck); // Refresh the assigned warehouses
      } else {
        const data = await response.json();
        alert(`Failed to assign warehouses. ${data.error}`);
      }
    } catch (error) {
      console.error('Error assigning warehouses:', error);
      alert('Failed to assign warehouses. Please try again.');
    }
  };

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">Assign Routes to Trucks</h1>

      {/* Truck Selection */}
      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">Select Truck:</label>
        <select
          className="p-2 border rounded w-full"
          onChange={handleTruckSelect}
          value={selectedTruck || ''}
        >
          <option value="" disabled>
            Select a truck
          </option>
          {trucks.map((truck) => (
            <option key={truck.uniqueId} value={truck.uniqueId}>
              {truck.name} {truck.uniqueId}
            </option>
          ))}
        </select>
      </div>

      {/* Warehouse Selection */}
      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">Select Warehouses:</label>
        <div className="grid grid-cols-2 gap-2">
          {warehouses.map((warehouse) => (
            <label key={warehouse.id} className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={selectedWarehouses.includes(warehouse.id)}
                onChange={() => handleWarehouseSelect(warehouse.id)}
              />
              {warehouse.name}
            </label>
          ))}
        </div>
      </div>

      {/* Assign Button */}
      <button
        className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        onClick={handleAssignWarehouses}
      >
        Assign Warehouses
      </button>

      {/* Display Assigned Warehouses */}
      {assignedWarehouses.length > 0 && (
        <div className="mt-6">
          <h2 className="text-lg font-semibold mb-2">Currently Assigned Warehouses:</h2>
          <ul className="list-disc pl-4">
            {assignedWarehouses.map((warehouse) => (
              <li key={warehouse.id}>{warehouse.name}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default AssignRoutes;
