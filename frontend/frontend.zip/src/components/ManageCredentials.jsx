import React from 'react';

const ManageCredentials = () => {
  return (
    <div style={{ padding: '20px' }}>
      <h1>ManageCredentials</h1>
      <p>This is the ManageCredentials page.</p>
    </div>
  );
};

export default ManageCredentials;
