import React from 'react';

const ReportsPage = () => {
  return (
    <div style={{ padding: '20px' }}>
      <h1>Reports</h1>
      <p>This is the Reports page. Add your reports-related content here.</p>
    </div>
  );
};

export default ReportsPage;
