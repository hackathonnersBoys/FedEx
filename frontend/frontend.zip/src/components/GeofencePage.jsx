import React, { useState, useEffect } from 'react';
import axios from 'axios';

const GeofencePage = () => {
  const [geofences, setGeofences] = useState([]);
  const [selectedGeofences, setSelectedGeofences] = useState([]);
  const [truckId, setTruckId] = useState('');
  const [message, setMessage] = useState('');

  // Fetch geofences when the component mounts
  useEffect(() => {
    const fetchGeofences = async () => {
      try {
        const response = await axios.get('/api/getGeofences', {
          params: { deviceId: 'your_device_id_here' } // Replace with actual device ID
        });
        setGeofences(response.data.geofences);
      } catch (error) {
        console.error('Error fetching geofences:', error);
      }
    };

    fetchGeofences();
  }, []);

  const handleGeofenceSelection = (geofenceId) => {
    setSelectedGeofences((prevSelected) => {
      if (prevSelected.includes(geofenceId)) {
        // Remove geofence ID if it's already selected
        return prevSelected.filter(id => id !== geofenceId);
      } else {
        // Add geofence ID to the list
        return [...prevSelected, geofenceId];
      }
    });
  };

  const handleUpdateRoute = async () => {
    if (!truckId || selectedGeofences.length === 0) {
      setMessage('Please select geofences and enter a truck ID.');
      return;
    }

    try {
      const response = await axios.post('/api/updateTruckRoute', {
        truckId: truckId,
        warehouseIds: selectedGeofences
      });

      setMessage(response.data.message);
    } catch (error) {
      console.error('Error updating truck route:', error);
      setMessage('Failed to update truck route.');
    }
  };

  return (
    <div>
      <h1>Geofence Selection</h1>

      <input
        type="text"
        placeholder="Enter Truck ID"
        value={truckId}
        onChange={(e) => setTruckId(e.target.value)}
      />

      <div>
        <h3>Select Geofences (Warehouses)</h3>
        {geofences.length > 0 ? (
          geofences.map((geofence) => (
            <div key={geofence.id}>
              <input
                type="checkbox"
                id={geofence.id}
                checked={selectedGeofences.includes(geofence.id)}
                onChange={() => handleGeofenceSelection(geofence.id)}
              />
              <label>{geofence.name} ({geofence.coordinates})</label>
            </div>
          ))
        ) : (
          <p>No geofences available.</p>
        )}
      </div>

      <button onClick={handleUpdateRoute}>Update Truck Route</button>

      {message && <p>{message}</p>}
    </div>
  );
};

export default GeofencePage;
