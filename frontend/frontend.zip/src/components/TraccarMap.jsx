import React, { useEffect, useRef, useState } from 'react';
import maplibregl from 'maplibre-gl';

const createCustomMarkerElement = (zoom) => {
  const element = document.createElement('div');
  element.className = 'custom-marker';
  
  // Adjust the size based on zoom level
  const size = zoom >= 14 ? 40 : 30;
  
  element.style.width = `${size}px`;
  element.style.height = `${size}px`;
  element.style.backgroundImage = 'url(/media/truck_top_view.png)';
  element.style.backgroundSize = 'cover';
  element.style.backgroundPosition = 'center';
  element.style.cursor = 'pointer';
  return element;
};

const createPopupContent = (position, deviceId, onReplayClick) => {
  const div = document.createElement('div');
  div.className = 'p-4';
  
  // Get current time and yesterday
  const now = new Date();
  const yesterday = new Date(now - 24 * 60 * 60 * 1000);

  // Format dates for display (local datetime-local format)
  const nowFormatted = now.toISOString().slice(0, 16);
  const yesterdayFormatted = yesterday.toISOString().slice(0, 16);
  
  div.innerHTML = `
    <div class="mb-4">
      <p class="mb-2"><strong>Device ID:</strong> ${deviceId}</p>
      <p class="mb-2"><strong>Speed:</strong> ${(position.speed * 1.852).toFixed(1)} km/h</p>
      <p class="mb-2"><strong>Battery:</strong> ${position.attributes.batteryLevel}%</p>
      <p class="mb-2"><strong>Accuracy:</strong> ${position.accuracy.toFixed(1)}m</p>
      <p class="mb-2"><strong>Last Update:</strong> ${new Date(position.deviceTime).toLocaleString()}</p>
    </div>
    <div class="border-t pt-4">
      <div class="mb-3">
        <label class="block text-sm mb-1">From:</label>
        <input type="datetime-local" id="fromDate-${deviceId}" value="${yesterdayFormatted}" class="w-full p-2 border rounded"/>
      </div>
      <div class="mb-3">
        <label class="block text-sm mb-1">To:</label>
        <input type="datetime-local" id="toDate-${deviceId}" value="${nowFormatted}" class="w-full p-2 border rounded"/>
      </div>
      <button id="replayBtn-${deviceId}" class="w-full bg-green-500 text-white p-2 rounded hover:bg-green-600">
        Show Path
      </button>
    </div>
  `;

  // Add event listener after the popup is added to DOM
  setTimeout(() => {
    const button = document.getElementById(`replayBtn-${deviceId}`);
    if (button) {
      button.addEventListener('click', () => {
        const fromDateInput = document.getElementById(`fromDate-${deviceId}`).value;
        const toDateInput = document.getElementById(`toDate-${deviceId}`).value;
        
        const fromDate = new Date(fromDateInput).toISOString();
        const toDate = new Date(toDateInput).toISOString();
        
        onReplayClick(deviceId, fromDate, toDate);
      });
    }
  }, 0);

  return div;
};

const TraccarMap = () => {
  const mapContainer = useRef(null);
  const map = useRef(null);
  const [markers, setMarkers] = useState({});
  const [truckLocations, setTruckLocations] = useState([]);
  const [currentTruckIndex, setCurrentTruckIndex] = useState(0);
  const [currentPopup, setCurrentPopup] = useState(null);
  const markersRef = useRef({});

  const token = 'RzBFAiEA9TdPYZkOoZGFxxv4ol07LdqDxc1N47-oljwMKoAMJ3MCID-fPyu0Yp77V7J0Qj0-9rVH2AFcIcJx00vpeBi5hGTPeyJ1IjoxLCJlIjoiMjAyNi0wMi0yOFQxNTozMDowMC4wMDArMDA6MDAifQ';
  const headers = new Headers({
    'Authorization': 'Bearer ' + token
  });

  const animateToTruck = (longitude, latitude) => {
    if (!map.current) return;

    // map.current.easeTo({
    //   center: [longitude, latitude],
    //   zoom: 17,
    //   duration: 1000,
    //   easing: t => t
    // });

    map.current.flyTo({
      center: [longitude, latitude],
      zoom: 17,
      pitch: 60,
      bearing: 10,
      speed: 2.2,
      curve: 1.5,
      easing: (t) => t
    });
  };

  const getColorFromSpeed = (speed) => {
    const speedKmh = (speed || 0) * 1.852;
    if (speedKmh <= 20) return '#ff0000';
    if (speedKmh <= 35) return '#ffa500';
    if (speedKmh <= 50) return '#ffff00';
    return '#00ff00';
  };

  const handleReplayClick = async (deviceId, fromDate, toDate) => {
    if (!map.current) return;

    try {
      const url = `http://localhost:8082/api/positions?deviceId=${deviceId}&from=${encodeURIComponent(fromDate)}&to=${encodeURIComponent(toDate)}`;
      const response = await fetch(url, { headers });
      
      if (!response.ok) {
        throw new Error('Failed to fetch path data');
      }

      const pathData = await response.json();
      
      if (pathData.length === 0) {
        alert('No historical data available for the selected time range');
        return;
      }

      pathData.sort((a, b) => new Date(a.deviceTime) - new Date(b.deviceTime));

      const features = [];
      for (let i = 0; i < pathData.length - 1; i++) {
        const speed = pathData[i].speed || 0;
        const color = getColorFromSpeed(speed);
        
        features.push({
          type: 'Feature',
          geometry: {
            type: 'LineString',
            coordinates: [
              [pathData[i].longitude, pathData[i].latitude],
              [pathData[i + 1].longitude, pathData[i + 1].latitude]
            ]
          },
          properties: {
            lineColor: color,
            speed: speed * 1.852,
            time: new Date(pathData[i].deviceTime).toLocaleString()
          }
        });
      }

      const source = map.current.getSource('path');
      if (source) {
        source.setData({
          type: 'FeatureCollection',
          features: features
        });
      } else {
        map.current.addSource('path', {
          type: 'geojson',
          data: {
            type: 'FeatureCollection',
            features: features
          }
        });

        map.current.addLayer({
          'id': 'path-line',
          'type': 'line',
          'source': 'path',
          'layout': {
            'line-join': 'round',
            'line-cap': 'round'
          },
          'paint': {
            'line-color': {
              'type': 'identity',
              'property': 'lineColor'
            },
            'line-width': 4
          }
        });
      }

      const coordinates = pathData.map(pos => [pos.longitude, pos.latitude]);
      const bounds = coordinates.reduce((bounds, coord) => {
        return [
          [Math.min(bounds[0][0], coord[0]), Math.min(bounds[0][1], coord[1])],
          [Math.max(bounds[1][0], coord[0]), Math.max(bounds[1][1], coord[1])]
        ];
      }, [[coordinates[0][0], coordinates[0][1]], [coordinates[0][0], coordinates[0][1]]]);

      map.current.fitBounds(bounds, { padding: 50 });

    } catch (error) {
      console.error('Error showing path:', error);
      alert('Error showing path. Please try again.');
    }
  };

  useEffect(() => {
    if (mapContainer.current && !map.current) {
      try {
        map.current = new maplibregl.Map({
          container: mapContainer.current,
          style: 'https://basemaps.cartocdn.com/gl/voyager-gl-style/style.json',
          center: [78.9629, 20.5937],
          zoom: 5
        });

        map.current.on('load', () => {
          map.current.addSource('path', {
            type: 'geojson',
            data: {
              type: 'FeatureCollection',
              features: []
            }
          });

          map.current.addLayer({
            'id': 'path-line',
            'type': 'line',
            'source': 'path',
            'layout': {
              'line-join': 'round',
              'line-cap': 'round'
            },
            'paint': {
              'line-color': {
                'type': 'identity',
                'property': 'lineColor'
              },
              'line-width': 4
            }
          });

          map.current.on('zoom', () => {
            const zoom = map.current.getZoom();
            Object.values(markers).forEach(marker => {
              const element = marker.getElement();
              const size = zoom >= 14 ? 40 : 30;
              element.style.width = `${size}px`;
              element.style.height = `${size}px`;
            });
          });

          updateVehicleLocations();
        });

      } catch (error) {
        console.error('Error initializing map:', error);
      }
    }

    return () => {
      if (map.current) {
        map.current.remove();
        map.current = null;
      }
    };
  }, []);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'ArrowLeft') {
        handlePrevTruck();
      } else if (e.key === 'ArrowRight') {
        handleNextTruck();
      }
    };

    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [currentTruckIndex, truckLocations]);




  const drawTruckRoute = async (deviceId) => {
  try {
    const response = await fetch(`http://localhost:3000/api/devices/${deviceId}/manage-geofence`);
    const data = await response.json();

    console.log("Route API Response:", data);

    if (data.message === "Geofence already exists for this truck.") {
      const area = data.geofence?.area;

      if (!area || !area.startsWith("LINESTRING(")) {
        alert("Invalid or missing LINESTRING data in the geofence.");
        return;
      }

      // Extract coordinates from LINESTRING
      const coordinates = area
        .replace("LINESTRING(", "")
        .replace(")", "")
        .split(",")
        .map(coord => coord.trim().split(" ").map(Number))
        .map(coord => [coord[1], coord[0]]);
        ;

      console.log("Extracted Coordinates:", coordinates);

      if (!coordinates || coordinates.length < 2) {
        alert("Route data is incomplete or invalid.");
        return;
      }

      // Check if the source already exists
      if (map.current.getSource("truck-route")) {
        console.log("Updating existing route source...");
        map.current.getSource("truck-route").setData({
          type: "Feature",
          geometry: {
            type: "LineString",
            coordinates: coordinates,
          },
        });
      } else {
        console.log("Adding new route source...");
        // Add source and layer if they don't exist
        map.current.addSource("truck-route", {
          type: "geojson",
          data: {
            type: "Feature",
            geometry: {
              type: "LineString",
              coordinates: coordinates,
            },
          },
        });

        map.current.addLayer({
          id: "truck-route",
          type: "line",
          source: "truck-route",
          layout: {
            "line-join": "round",
            "line-cap": "round",
          },
          paint: {
            "line-color": "#007aff",
            "line-width": 4,
          },
        });
      }

      // Fit the map to the route
      const bounds = coordinates.reduce(
        (bounds, coord) => bounds.extend(coord),
        new maplibregl.LngLatBounds(coordinates[0], coordinates[0])
      );
      map.current.fitBounds(bounds, { padding: 50 });
    } else {
      alert(data.message || "Unable to fetch the route for this truck.");
    }
  } catch (error) {
    console.error("Error fetching truck route:", error);
    alert("Failed to fetch the truck route.");
  }
};

  
 


  const updateVehicleLocations = async () => {
    if (!map.current) return;

    try {
      const response = await fetch('http://localhost:8082/api/positions', { headers });
      const data = await response.json();

      data.forEach(position => {
        const { latitude: lat, longitude: lon, deviceId } = position;
        
        if (!markersRef.current[deviceId]) {
          const zoom = map.current.getZoom();
          const element = createCustomMarkerElement(zoom);
          
          const marker = new maplibregl.Marker({
            element: element,
            clickTolerance: 3
          })
            .setLngLat([lon, lat])
            .addTo(map.current);

          // Add click handler to the marker element
          marker.getElement().addEventListener('click', (e) => {
            e.stopPropagation(); // Prevent event bubbling
            animateToTruck(lon, lat);
            
            // Show popup after a short delay to allow zoom animation
            
            drawTruckRoute(deviceId);

            setTimeout(() => {
              const popupContent = createPopupContent(
                position,
                deviceId,
                handleReplayClick
              );
              
              new maplibregl.Popup({ offset: 25 })
                .setLngLat([lon, lat])
                .setDOMContent(popupContent)
                .addTo(map.current);
            }, 1000);
          });

          markersRef.current[deviceId] = marker;
        } else {
          markersRef.current[deviceId].setLngLat([lon, lat]);
        }
      });

      setTruckLocations(data);
    } catch (error) {
      console.error('Error fetching Traccar data:', error);
    }

    setTimeout(updateVehicleLocations, 1000);
  };

  const handlePrevTruck = () => {
    if (truckLocations.length > 0 && map.current) {
      const newIndex = (currentTruckIndex - 1 + truckLocations.length) % truckLocations.length;
      setCurrentTruckIndex(newIndex);
      const truck = truckLocations[newIndex];
      animateToTruck(truck.longitude, truck.latitude);
      
      if (currentPopup) {
        currentPopup.remove();
      }

      setTimeout(() => {
        const popupContent = createPopupContent(truck, truck.deviceId, handleReplayClick);
        
        const popup = new maplibregl.Popup({ offset: 25 })
          .setLngLat([truck.longitude, truck.latitude])
          .setDOMContent(popupContent)
          .addTo(map.current);

          setCurrentPopup(popup);
      }, 1200);        
    }
  };

  const handleNextTruck = () => {
    if (truckLocations.length > 0 && map.current) {
      const newIndex = (currentTruckIndex + 1) % truckLocations.length;
      setCurrentTruckIndex(newIndex);
      const truck = truckLocations[newIndex];
      animateToTruck(truck.longitude, truck.latitude);
      
      if (currentPopup) {
        currentPopup.remove();
      }

      setTimeout(() => {
        const popupContent = createPopupContent(truck, truck.deviceId, handleReplayClick);
        
        const popup = new maplibregl.Popup({ offset: 25 })
          .setLngLat([truck.longitude, truck.latitude])
          .setDOMContent(popupContent)
          .addTo(map.current);

          setCurrentPopup(popup);
      }, 1200);
    }
  };

  
  return (
    <div className="relative w-full h-full" style={{ position: 'relative', width: '100%', height: '100vh' }}>
      <div style={{ display: 'flex', width: '100%', height: '100%' }}>
        {/* Left Panel - adjust contents as desired */}
        <div style={{ width: '400px', overflowY: 'auto', background: '#f4f4f4', padding: '20px' }}>
          <h1>Traccar Map Control Panel</h1>
          <p>
            Use this panel for additional controls, filters, or information about the trucks.
          </p>
          <div className="flex items-center gap-2 bg-black/30 p-2 rounded-lg z-20" style={{ marginBottom: '10px', marginTop: '20px', backgroundColor: 'rgba(0,0,0,0.3)' }}>
            <button
              style={{
                backgroundColor: 'rgba(0,0,0,0.5)',
                color: 'white',
                padding: '5px 10px',
                borderRadius: '5px',
                cursor: 'pointer',
                marginRight: '10px'
              }}
              onClick={handlePrevTruck}
            >
              ← Previous
            </button>

            <div style={{ color: 'white', backgroundColor: 'rgba(0,0,0,0.4)', padding: '5px 10px', borderRadius: '5px' }}>
              {truckLocations.length > 0 ? `${currentTruckIndex + 1}/${truckLocations.length}` : '0/0'}
            </div>

            <button
              style={{
                backgroundColor: 'rgba(0,0,0,0.5)',
                color: 'white',
                padding: '5px 10px',
                borderRadius: '5px',
                cursor: 'pointer'
              }}
              onClick={handleNextTruck}
            >
              Next →
            </button>
          </div>

          <button
            style={{
              backgroundColor: 'rgba(0,0,0,0.5)',
              color: 'white',
              padding: '5px 10px',
              borderRadius: '5px',
              cursor: 'pointer'
            }}
            onClick={() => {
              if (map.current) {
                map.current.easeTo({
                  zoom: 5,
                  duration: 1000
                });
              }
            }}
          >
            Reset View
          </button>
        </div>

        {/* Map Container */}
        <div style={{ flex: 1, position: 'relative' }}>
          <div
            ref={mapContainer}
            className="absolute inset-0"
            style={{ position: 'absolute', top: 0, bottom: 0, left: 0, right: 0 }}
          ></div>
        </div>
      </div>
    </div>
  );
};



export default TraccarMap;