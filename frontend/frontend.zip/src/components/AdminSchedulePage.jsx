import React, { useEffect, useState, useContext } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { UserContext } from './UserContext';

const AdminSchedulePage = () => {
  const { warehouseAccess } = useContext(UserContext); // Access warehouseAccess from context
  const [trucks, setTrucks] = useState([]);
  const [selectedTruck, setSelectedTruck] = useState(null);
  const [map, setMap] = useState(null);
  const [currentLocation, setCurrentLocation] = useState(null);

  useEffect(() => {
    // Initialize the MapLibre map
    const mapInstance = new maplibregl.Map({
      container: 'map',
      style: 'https://demotiles.maplibre.org/style.json',
      center: [78.9629, 20.5937], // Default center (India)
      zoom: 4,
    });

    setMap(mapInstance);

    // Cleanup map instance on component unmount
    return () => mapInstance.remove();
  }, []);

  useEffect(() => {
    // Fetch trucks for all accessible warehouses
    if (warehouseAccess) {
      const warehouseIds = warehouseAccess.split(',').map((id) => id.trim()); // Split and trim IDs
      fetchAllTrucks(warehouseIds);
    }
  }, [warehouseAccess]);

  const fetchAllTrucks = async (warehouseIds) => {
    const allTrucks = [];

    for (const warehouseId of warehouseIds) {
      try {
        const response = await fetch(`/api/getScheduledTrucks?warehouseId=${warehouseId}`); // Replace with your API endpoint
        const data = await response.json();
        if (data) {
          allTrucks.push(...data); // Combine trucks from all warehouses
        }
      } catch (err) {
        console.error(`Error fetching trucks for warehouse ${warehouseId}:`, err);
      }
    }

    setTrucks(allTrucks);
  };

  const handleTruckClick = (truck) => {
    setSelectedTruck(truck);

    // Simulated route data for the selected truck
    const routeCoordinates = truck.route_warehouse_ids.map((id, index) => [
      78.9629 + index * 0.1, // Mocked longitude
      20.5937 + index * 0.1, // Mocked latitude
    ]);
    const currentLocation = routeCoordinates[0]; // Simulated current location

    if (map) {
      map.flyTo({ center: currentLocation, zoom: 11 });

      // Add the truck route as a line
      if (map.getSource('route')) {
        map.getSource('route').setData({
          type: 'Feature',
          geometry: {
            type: 'LineString',
            coordinates: routeCoordinates,
          },
        });
      } else {
        map.addSource('route', {
          type: 'geojson',
          data: {
            type: 'Feature',
            geometry: {
              type: 'LineString',
              coordinates: routeCoordinates,
            },
          },
        });

        map.addLayer({
          id: 'route',
          type: 'line',
          source: 'route',
          layout: {
            'line-join': 'round',
            'line-cap': 'round',
          },
          paint: {
            'line-color': '#007bff',
            'line-width': 4,
          },
        });
      }

      // Highlight the current location
      setCurrentLocation(currentLocation);

      if (map.getSource('current-location')) {
        map.getSource('current-location').setData({
          type: 'Feature',
          geometry: {
            type: 'Point',
            coordinates: currentLocation,
          },
        });
      } else {
        map.addSource('current-location', {
          type: 'geojson',
          data: {
            type: 'Feature',
            geometry: {
              type: 'Point',
              coordinates: currentLocation,
            },
          },
        });

        map.addLayer({
          id: 'current-location',
          type: 'circle',
          source: 'current-location',
          paint: {
            'circle-radius': 10,
            'circle-color': '#ff0000',
          },
        });
      }
    }
  };

  return (
    <div style={{ display: 'flex' }}>
      <div style={{ flex: 1, padding: '20px' }}>
        <h1>Admin Truck Schedule</h1>

        <table border="1" style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              <th>Truck ID</th>
              <th>Name</th>
              <th>Route</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {trucks.length > 0 ? (
              trucks.map((truck) => (
                <tr key={truck.truck_id}>
                  <td>{truck.truck_id}</td>
                  <td>{truck.truck_name}</td>
                  <td>
                    {truck.route_warehouse_names.join(', ')} {/* Display route */}
                  </td>
                  <td>
                    <button onClick={() => handleTruckClick(truck)}>View Route</button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4" style={{ textAlign: 'center' }}>
                  No trucks available.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div
        id="map"
        style={{
          flex: 1,
          height: '100vh',
          borderLeft: '1px solid #ccc',
        }}
      ></div>
    </div>
  );
};

export default AdminSchedulePage;
