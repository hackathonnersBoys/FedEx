import React from 'react';

const PermissionsPage = () => {
  return (
    <div style={{ padding: '20px' }}>
      <h1>PermissionsPage</h1>
      <p>This is the PermissionsPage page.</p>
    </div>
  );
};

export default PermissionsPage;
