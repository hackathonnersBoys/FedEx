import React from 'react';

const AddUser = () => {
  return (
    <div style={{ padding: '20px' }}>
      <h1>Add User</h1>
      <p>Form to add new users will go here.</p>
    </div>
  );
};

export default AddUser;
