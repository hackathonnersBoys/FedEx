import React, { createContext, useState, useEffect } from 'react';

export const UserContext = createContext();

export const UserProvider = ({ children }) => {
  const [userRole, setUserRole] = useState(null);
  const [warehouseAccess, setWarehouseAccess] = useState('');

  // Optional: persist user data in localStorage
  useEffect(() => {
    const storedUserRole = localStorage.getItem('userRole');
    const storedWarehouseAccess = localStorage.getItem('warehouseAccess');
    if (storedUserRole) setUserRole(storedUserRole);
    if (storedWarehouseAccess) setWarehouseAccess(storedWarehouseAccess);
  }, []);

  useEffect(() => {
    if (userRole) localStorage.setItem('userRole', userRole);
    if (warehouseAccess) localStorage.setItem('warehouseAccess', warehouseAccess);
  }, [userRole, warehouseAccess]);

  return (
    <UserContext.Provider value={{ userRole, setUserRole, warehouseAccess, setWarehouseAccess }}>
      {children}
    </UserContext.Provider>
  );
};
