import React, { useState, useEffect } from 'react';

const AddTruck = () => {
  const [formData, setFormData] = useState({
    name: '',
    uniqueId: '',
    max_volume: '',
    max_weight: '',
    MMS: '',
    driver: '',
    route: '',
  });
  const [drivers, setDrivers] = useState([]);
  const [mmsList, setMmsList] = useState([]);
  const [routes, setRoutes] = useState([]);
  const [message, setMessage] = useState(null);

  useEffect(() => {
    fetchDrivers();
    fetchMMS();
    fetchRoutes();
  }, []);

  // Fetch drivers
  const fetchDrivers = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/drivers'); // Replace with your actual driver API URL
      const data = await response.json();
      setDrivers(data);
    } catch (error) {
      console.error('Error fetching drivers:', error);
    }
  };

  // Fetch MMS
  const fetchMMS = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/mms'); // Replace with your actual MMS API URL
      const data = await response.json();
      setMmsList(data);
    } catch (error) {
      console.error('Error fetching MMS:', error);
    }
  };

  // Fetch Routes
  const fetchRoutes = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/routes'); // Replace with your actual routes API URL
      const data = await response.json();
      setRoutes(data);
    } catch (error) {
      console.error('Error fetching routes:', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch('http://localhost:3000/api/devices/new', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error('Failed to add truck');
      }

      const data = await response.json();
      setMessage({ type: 'success', text: `Truck ${data.name} added successfully!` });
      setFormData({
        name: '',
        uniqueId: '',
        max_volume: '',
        max_weight: '',
        MMS: '',
        driver: '',
        route: '',
      });
    } catch (error) {
      console.error('Error adding truck:', error);
      setMessage({ type: 'error', text: 'Failed to add truck. Please try again.' });
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: 'auto' }}>
      <h1>Add Truck</h1>
      {message && (
        <p
          style={{
            color: message.type === 'success' ? 'green' : 'red',
            fontWeight: 'bold',
          }}
        >
          {message.text}
        </p>
      )}
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: '15px' }}>
          <label>
            <strong>Truck Name:</strong>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              required
              style={{ width: '100%', padding: '8px', marginTop: '5px' }}
            />
          </label>
        </div>
        <div style={{ marginBottom: '15px' }}>
          <label>
            <strong>Unique ID:</strong>
            <input
              type="text"
              name="uniqueId"
              value={formData.uniqueId}
              onChange={handleInputChange}
              required
              style={{ width: '100%', padding: '8px', marginTop: '5px' }}
            />
          </label>
        </div>
        <div style={{ marginBottom: '15px' }}>
          <label>
            <strong>Max Volume:</strong>
            <input
              type="number"
              name="max_volume"
              value={formData.max_volume}
              onChange={handleInputChange}
              required
              style={{ width: '100%', padding: '8px', marginTop: '5px' }}
            />
          </label>
        </div>
        <div style={{ marginBottom: '15px' }}>
          <label>
            <strong>Max Weight:</strong>
            <input
              type="number"
              name="max_weight"
              value={formData.max_weight}
              onChange={handleInputChange}
              required
              style={{ width: '100%', padding: '8px', marginTop: '5px' }}
            />
          </label>
        </div>
        <div style={{ marginBottom: '15px' }}>
          <label>
            <strong>MMS:</strong>
            <select
              name="MMS"
              value={formData.MMS}
              onChange={handleInputChange}
              required
              style={{ width: '100%', padding: '8px', marginTop: '5px' }}
            >
              <option value="">Select MMS</option>
              {mmsList.map((mms) => (
                <option key={mms.id} value={mms.id}>
                  {mms.name}
                </option>
              ))}
            </select>
          </label>
        </div>
        <div style={{ marginBottom: '15px' }}>
          <label>
            <strong>Driver:</strong>
            <select
              name="driver"
              value={formData.driver}
              onChange={handleInputChange}
              required
              style={{ width: '100%', padding: '8px', marginTop: '5px' }}
            >
              <option value="">Select Driver</option>
              {drivers.map((driver) => (
                <option key={driver.id} value={driver.id}>
                  {driver.name}
                </option>
              ))}
            </select>
          </label>
        </div>
        <div style={{ marginBottom: '15px' }}>
          <label>
            <strong>Route:</strong>
            <select
              name="route"
              value={formData.route}
              onChange={handleInputChange}
              required
              style={{ width: '100%', padding: '8px', marginTop: '5px' }}
            >
              <option value="">Select Route</option>
              {routes.map((route) => (
                <option key={route.id} value={route.id}>
                  {route.name}
                </option>
              ))}
            </select>
          </label>
        </div>
        <button
          type="submit"
          style={{
            backgroundColor: '#007bff',
            color: '#fff',
            border: 'none',
            padding: '10px 15px',
            borderRadius: '5px',
            cursor: 'pointer',
          }}
        >
          Add Truck
        </button>
      </form>
    </div>
  );
};

export default AddTruck;
