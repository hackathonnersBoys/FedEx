import React, { useContext } from 'react';
import { UserContext } from './UserContext';


const AdminDashboard = () => {
  return (
    <div style={{ padding: '20px' }}>
      <h1>AdminDashboard</h1>
      <p>This is the AdminDashboard page. </p>
    </div>
  );
};

export default AdminDashboard;
