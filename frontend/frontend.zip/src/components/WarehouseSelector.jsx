import React, { useState, useEffect } from 'react';

const WarehouseSelector = ({ onWarehousesSelected }) => {
  const [warehouses, setWarehouses] = useState([]);
  const [selectedWarehouses, setSelectedWarehouses] = useState([]);

  // Helper function to parse the POLYGON string
  const parsePolygon = (area) => {
    const coordinates = area
      .replace('POLYGON((', '')
      .replace('))', '')
      .split(',')
      .map((coord) => coord.trim().split(' ').map(Number));

    // Return the first coordinate as the representative point
    return coordinates[0];
  };

  // Fetch geofences (warehouses) from API
  useEffect(() => {
    const fetchWarehouses = async () => {
      try {
        const response = await fetch('http://localhost:3000/api/geofences'); // Replace with your geofence API endpoint
        const data = await response.json();

        // Map geofences to warehouses with parsed coordinates
        const parsedData = data.map((geofence) => {
          const [longitude, latitude] = parsePolygon(geofence.area);
          return {
            id: geofence.id,
            name: geofence.name,
            latitude,
            longitude,
          };
        });

        setWarehouses(parsedData);
      } catch (error) {
        console.error('Error fetching warehouses:', error);
      }
    };

    fetchWarehouses();
  }, []);

  // Handle warehouse selection
  const handleSelectWarehouse = (warehouseId) => {
    setSelectedWarehouses((prevSelected) =>
      prevSelected.includes(warehouseId)
        ? prevSelected.filter((id) => id !== warehouseId)
        : [...prevSelected, warehouseId]
    );
  };

  // Update selected warehouses and pass coordinates to parent
  useEffect(() => {
    const selectedCoords = warehouses
      .filter((warehouse) => selectedWarehouses.includes(warehouse.id))
      .map((warehouse) => [warehouse.longitude, warehouse.latitude]);

    onWarehousesSelected(selectedCoords); // Pass selected coordinates to parent
  }, [selectedWarehouses, warehouses, onWarehousesSelected]);

  return (
    <div className="warehouse-selector p-4 bg-white rounded shadow">
      <h2 className="text-lg font-bold mb-4">Select Warehouses</h2>
      {warehouses.length === 0 ? (
        <p>Loading warehouses...</p>
      ) : (
        <ul className="list-none">
          {warehouses.map((warehouse) => (
            <li key={warehouse.id} className="mb-2 flex items-center">
              <input
                type="checkbox"
                id={`warehouse-${warehouse.id}`}
                checked={selectedWarehouses.includes(warehouse.id)}
                onChange={() => handleSelectWarehouse(warehouse.id)}
                className="mr-2"
              />
              <label htmlFor={`warehouse-${warehouse.id}`} className="cursor-pointer">
                {warehouse.name} ({warehouse.latitude.toFixed(6)}, {warehouse.longitude.toFixed(6)})
              </label>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default WarehouseSelector;
