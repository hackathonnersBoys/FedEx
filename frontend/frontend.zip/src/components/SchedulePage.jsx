import React, { useEffect, useState, useContext } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { UserContext } from './UserContext';

const SchedulePage = () => {
  const { warehouseAccess } = useContext(UserContext); // Access warehouseAccess from context
  const [trucks, setTrucks] = useState([]);
  const [expandedTruckId, setExpandedTruckId] = useState(null);
  const [map, setMap] = useState(null);
  const [routeDetails, setRouteDetails] = useState([]); // Store parsed route details

  useEffect(() => {
    // Initialize the MapLibre map
    const mapInstance = new maplibregl.Map({
      container: 'map',
      style: 'https://demotiles.maplibre.org/style.json',
      center: [78.9629, 20.5937], // Default center (India)
      zoom: 4,
    });

    setMap(mapInstance);

    // Cleanup map instance on component unmount
    return () => mapInstance.remove();
  }, []);

  useEffect(() => {
    // Fetch trucks for all accessible warehouses
    if (warehouseAccess) {
      const warehouseIds = warehouseAccess.split(',').map((id) => id.trim()); // Split and trim IDs
      fetchAllTrucks(warehouseIds);
    }
  }, [warehouseAccess]);

  const fetchAllTrucks = async (warehouseIds) => {
    const allTrucks = [];
    const addedTruckIds = new Set(); // Track unique truck IDs

    for (const warehouseId of warehouseIds) {
      try {
        const response = await fetch(`/api/getScheduledTrucks?warehouseId=${warehouseId}`);
        const data = await response.json();

        if (data) {
          data.forEach((truck) => {
            if (!addedTruckIds.has(truck.truck_id)) {
              addedTruckIds.add(truck.truck_id);
              allTrucks.push(truck);
            }
          });
        }
      } catch (err) {
        console.error(`Error fetching trucks for warehouse ${warehouseId}:`, err);
      }
    }

    setTrucks(allTrucks);
  };

  const handleTruckClick = async (truck) => {
    // Toggle expandedTruckId
    if (expandedTruckId === truck.truck_id) {
      setExpandedTruckId(null); // Collapse the details
      setRouteDetails([]); // Clear route details
      return;
    }

    try {
      const idResponse = await fetch(`/api/devices/getId?uniqueId=${truck.truck_id}`);
      if (!idResponse.ok) throw new Error(`Error fetching actual ID: ${idResponse.status}`);
      const idData = await idResponse.json();
      const actualId = idData.id; // Assuming the API returns the actual_id in this field

      const geofenceResponse = await fetch(`/api/devices/${actualId}/manage-geofence`);
      if (!geofenceResponse.ok) throw new Error(`Error fetching geofence: ${geofenceResponse.status}`);
      const geofenceData = await geofenceResponse.json();
      const geofenceArea = geofenceData.geofence.area; // Assuming the geofence area is in "area" field

      const routeCoordinates = parseLineString(geofenceArea); // Parse LINESTRING into coordinates
      updateMapWithRoute(routeCoordinates);

      // Expand the selected truck row for additional details
      setExpandedTruckId(truck.truck_id);

      // Parse route_estimated_arrival if present and display it in a structured format
      if (truck.route_estimated_arrival) {
        try {
          const details = JSON.parse(truck.route_estimated_arrival);
          setRouteDetails(details);
        } catch (err) {
          console.error('Error parsing route_estimated_arrival:', err);
          setRouteDetails([]);
        }
      } else {
        setRouteDetails([]);
      }
    } catch (err) {
      console.error('Error:', err);
    }
  };

  const updateMapWithRoute = (coordinates) => {
    if (!map || !coordinates.length) return;

    // Calculate the center of the route
    const center = calculateCenter(coordinates);

    map.flyTo({
      center, // Fly to the center of the route
      zoom: 11,
    });

    if (map.getSource('route')) {
      map.getSource('route').setData({
        type: 'Feature',
        geometry: {
          type: 'LineString',
          coordinates,
        },
      });
    } else {
      map.addSource('route', {
        type: 'geojson',
        data: {
          type: 'Feature',
          geometry: {
            type: 'LineString',
            coordinates,
          },
        },
      });

      map.addLayer({
        id: 'route',
        type: 'line',
        source: 'route',
        layout: {
          'line-join': 'round',
          'line-cap': 'round',
        },
        paint: {
          'line-color': '#007bff',
          'line-width': 4,
        },
      });
    }
  };

  // Helper function to parse LINESTRING into coordinates
  const parseLineString = (lineString) => {
    // Remove "LINESTRING(" and ")"
    const coordinateString = lineString.replace('LINESTRING(', '').replace(')', '');
    // Split into coordinate pairs
    const pairs = coordinateString.split(',');
    // Convert pairs into [longitude, latitude] arrays
    return pairs.map((pair) => {
      const [lat, lon] = pair.trim().split(' ');
      return [parseFloat(lon), parseFloat(lat)];
    });
  };

  // Helper function to calculate the center of a route
  const calculateCenter = (coordinates) => {
    const total = coordinates.reduce(
      (acc, coord) => {
        acc[0] += coord[0]; // Sum of longitudes
        acc[1] += coord[1]; // Sum of latitudes
        return acc;
      },
      [0, 0]
    );

    return [total[0] / coordinates.length, total[1] / coordinates.length];
  };

  return (
    <div style={{ display: 'flex' }}>
      <div style={{ flex: 1, padding: '20px' }}>
        <h1>Admin Truck Schedule</h1>
        <table border="1" style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '20px' }}>
          <thead>
            <tr>
              <th>Truck ID</th>
              <th>Truck Name</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {trucks.length > 0 ? (
              trucks.map((truck) => (
                <React.Fragment key={truck.truck_id}>
                  <tr onClick={() => handleTruckClick(truck)}>
                    <td>{truck.truck_id}</td>
                    <td>{truck.truck_name}</td>
                    <td>
                      <button>
                        {expandedTruckId === truck.truck_id ? 'Hide Details' : 'View Route & Schedule'}
                      </button>
                    </td>
                  </tr>
                  {expandedTruckId === truck.truck_id && (
                    <tr>
                      <td colSpan="3">
                        {routeDetails.length > 0 ? (
                          <table border="1" style={{ width: '100%', borderCollapse: 'collapse' }}>
                            <thead>
                              <tr>
                                <th>From</th>
                                <th>To</th>
                                <th>Estimated Arrival Time</th>
                              </tr>
                            </thead>
                            <tbody>
                              {routeDetails.map((segment, index) => (
                                <tr key={index}>
                                  <td>{segment.from}</td>
                                  <td>{segment.to}</td>
                                  <td>{new Date(segment.arrival_time).toLocaleString()}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        ) : (
                          <p>No route schedule available</p>
                        )}
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))
            ) : (
              <tr>
                <td colSpan="3" style={{ textAlign: 'center' }}>
                  No trucks available.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div
        id="map"
        style={{
          flex: 1,
          height: '100vh',
          borderLeft: '1px solid #ccc',
        }}
      ></div>
    </div>
  );
};

export default SchedulePage;
