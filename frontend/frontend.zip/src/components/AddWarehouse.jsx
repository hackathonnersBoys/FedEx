import React, { useEffect, useRef, useState } from 'react';
import maplibregl from 'maplibre-gl';

const AddWarehouse = () => {
  const mapContainer = useRef(null);
  const map = useRef(null);
  const [currentPopup, setCurrentPopup] = useState(null);
  const [warehouses, setWarehouses] = useState([]);

  useEffect(() => {
    if (mapContainer.current && !map.current) {
      map.current = new maplibregl.Map({
        container: mapContainer.current,
        style: 'https://basemaps.cartocdn.com/gl/voyager-gl-style/style.json',
        center: [78.9629, 20.5937], // Center on India
        zoom: 5,
      });

      map.current.on('click', (e) => {
        const { lng, lat } = e.lngLat;
        showCreateWarehousePopup(lng, lat);
      });

      fetchGeofences(); // Fetch existing geofences

      return () => {
        if (map.current) {
          map.current.remove();
          map.current = null;
        }
      };
    }
  }, []);

  const fetchGeofences = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/geofences', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        console.error('Failed to fetch geofences:', response.status, response.statusText);
        return;
      }

      const data = await response.json();
      data.forEach((geofence) => {
        if (geofence.area.startsWith('POLYGON')) {
          displayGeofenceOnMap(geofence);
        }
      });
    } catch (error) {
      console.error('Error fetching geofences:', error);
    }
  };

  const showCreateWarehousePopup = (lng, lat) => {
    if (currentPopup) currentPopup.remove();

    const popupContent = document.createElement('div');
    popupContent.innerHTML = `
      <div>
        <p>Create a warehouse at:</p>
        <p><strong>${lng.toFixed(4)}, ${lat.toFixed(4)}</strong></p>
        <button id="createWarehouseBtn" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 mt-2">
          Create Warehouse
        </button>
      </div>
    `;

    setTimeout(() => {
      const button = document.getElementById('createWarehouseBtn');
      if (button) {
        button.addEventListener('click', () => handleAddWarehouse(lng, lat));
      }
    }, 0);

    const popup = new maplibregl.Popup({ offset: 25 })
      .setLngLat([lng, lat])
      .setDOMContent(popupContent)
      .addTo(map.current);

    setCurrentPopup(popup);
  };

  const handleAddWarehouse = async (lng, lat) => {
    const newWarehouse = {
      id: warehouses.length + 1,
      lng,
      lat,
    };

    setWarehouses([...warehouses, newWarehouse]);
    addWarehouseMarker(lng, lat, newWarehouse.id);

    if (currentPopup) {
      currentPopup.remove();
      setCurrentPopup(null);
    }

    await createGeofence(newWarehouse.id, lng, lat);
  };

  const createGeofence = async (warehouseId, lng, lat) => {
    const delta = 0.0003; // Size of the rectangle (approximately 200m)

    const rectangleCoordinates = [
      [lat + delta, lng - delta],
      [lat + delta, lng + delta],
      [lat - delta, lng + delta],
      [lat - delta, lng - delta],
      [lat + delta, lng - delta], // Close the loop
    ];

    const geofenceData = {
      name: `Warehouse ${warehouseId}`,
      description: `Geofence for Warehouse ${warehouseId}`,
      area: `POLYGON((${rectangleCoordinates.map((coord) => coord.join(' ')).join(', ')}))`,
    };

    try {
      const response = await fetch('http://localhost:3000/api/geofences', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(geofenceData),
      });

      if (!response.ok) {
        throw new Error('Failed to create geofence');
      }

      const data = await response.json();
      displayGeofenceOnMap(data);
      alert(`Geofence created for Warehouse ${warehouseId}`);
    } catch (error) {
      console.error('Error creating geofence:', error);
      alert('Failed to create geofence. Please try again.');
    }
  };

  const addWarehouseMarker = (lng, lat, id) => {
    new maplibregl.Marker({ color: '#007bff' })
      .setLngLat([lng, lat])
      .setPopup(
        new maplibregl.Popup({ offset: 25 }).setHTML(`
          <div>
            <p><strong>Warehouse ID:</strong> ${id}</p>
            <p><strong>Location:</strong> ${lng.toFixed(4)}, ${lat.toFixed(4)}</p>
          </div>
        `)
      )
      .addTo(map.current);
  };

  const displayGeofenceOnMap = (geofence) => {
    const match = /POLYGON\(\(\s*([^)]+)\s*\)\)/.exec(geofence.area);
    if (!match) {
      console.warn('Could not parse geofence area:', geofence.area);
      return;
    }

    const coordinates = match[1]
      .split(', ')
      .map((coord) => coord.split(' ').map(Number))
      .map((coord) => [coord[1], coord[0]]);

    const sourceId = `geofence-${geofence.id}`;

    if (!map.current.getSource(sourceId)) {
      map.current.addSource(sourceId, {
        type: 'geojson',
        data: {
          type: 'FeatureCollection',
          features: [
            {
              type: 'Feature',
              geometry: {
                type: 'Polygon',
                coordinates: [coordinates],
              },
            },
          ],
        },
      });

      map.current.addLayer({
        id: `geofence-layer-${geofence.id}`,
        type: 'fill',
        source: sourceId,
        paint: {
          'fill-color': '#ff0000',
          'fill-opacity': 0.3,
        },
      });

      map.current.addLayer({
        id: `geofence-outline-${geofence.id}`,
        type: 'line',
        source: sourceId,
        paint: {
          'line-color': '#ff0000',
          'line-width': 2,
        },
      });
      
      new maplibregl.Marker({ color: '#ff0000' })
        .setLngLat([coordinates[0][0], coordinates[0][1]]) // Use [longitude, latitude]
        .setPopup(
          new maplibregl.Popup({ offset: 25 }).setHTML(`
            <div>
              <p><strong>Geofence ID:</strong> ${geofence.id}</p>
              <p><strong>Name:</strong> ${geofence.name}</p>
              <p><strong>Description:</strong> ${geofence.description}</p>
            </div>
          `)
        )
        .addTo(map.current);
        
    }
  };

  return (
    <div style={{ height: '100vh', position: 'relative' }}>
      <h1 style={{ position: 'absolute', zIndex: 1000, margin: '10px' }}>Add Warehouse</h1>
      <div
        ref={mapContainer}
        style={{ position: 'absolute', top: 0, bottom: 0, left: 0, right: 0 }}
      />
      <button
        style={{
          position: 'absolute',
          top: '20px',
          right: '20px',
          zIndex: 1000,
          backgroundColor: '#007bff',
          color: '#fff',
          border: 'none',
          padding: '10px 20px',
          borderRadius: '5px',
          cursor: 'pointer',
        }}
        onClick={() => {
          if (map.current) {
            map.current.easeTo({
              zoom: 5,
              center: [78.9629, 20.5937],
              duration: 1000,
            });
          }
        }}
      >
        Reset View
      </button>
    </div>
  );
};

export default AddWarehouse;
