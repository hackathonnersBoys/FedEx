import React, { useEffect, useRef, useState } from 'react';
import maplibregl from 'maplibre-gl';

const WarehouseDetails = ({ geofence, onClose }) => {
  return (
    <div
      style={{
        position: 'absolute',
        top: '80px',
        right: '20px',
        zIndex: 1000,
        background: '#fff',
        padding: '20px',
        borderRadius: '5px',
        maxWidth: '300px',
        boxShadow: '0 2px 10px rgba(0,0,0,0.3)',
      }}
    >
      <button style={{ float: 'right' }} onClick={onClose}>
        X
      </button>
      <h2>{geofence.name}</h2>
      <p><strong>ID:</strong> {geofence.id}</p>
      <p><strong>Description:</strong> {geofence.description}</p>
      {/* Add any additional details or nested components here */}
    </div>
  );
};

const ViewWarehouse = () => {
  const mapContainer = useRef(null);
  const map = useRef(null);
  const [currentPopup, setCurrentPopup] = useState(null);
  const [warehouses, setWarehouses] = useState([]);
  const [selectedGeofence, setSelectedGeofence] = useState(null);

  useEffect(() => {
    if (mapContainer.current && !map.current) {
      map.current = new maplibregl.Map({
        container: mapContainer.current,
        style: 'https://basemaps.cartocdn.com/gl/voyager-gl-style/style.json',
        center: [78.9629, 20.5937], // Center on India
        zoom: 5,
      });

      // Wait for the map to load before fetching geofences and adding layers
      map.current.on('load', () => {
        fetchGeofences();
      });

      return () => {
        if (map.current) {
          map.current.remove();
          map.current = null;
        }
      };
    }
  }, []);

  const fetchGeofences = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/geofences', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        console.error('Failed to fetch geofences:', response.status, response.statusText);
        return;
      }

      const data = await response.json();
      data.forEach((geofence) => {
        if (geofence.area.startsWith('POLYGON')) {
          displayGeofenceOnMap(geofence);
        }
      });
      setWarehouses(data);
    } catch (error) {
      console.error('Error fetching geofences:', error);
    }
  };

  const displayGeofenceOnMap = (geofence) => {
    const match = /POLYGON\(\(\s*([^)]+)\s*\)\)/.exec(geofence.area);
    if (!match) {
      console.warn('Could not parse geofence area:', geofence.area);
      return;
    }
  
    const coordinates = match[1]
      .split(', ')
      .map((coord) => coord.split(' ').map(Number))
      .map((coord) => [coord[1], coord[0]]);
  
    const sourceId = `geofence-${geofence.id}`;
  
    if (!map.current.getSource(sourceId)) {
      // Add the geofence source
      map.current.addSource(sourceId, {
        type: 'geojson',
        data: {
          type: 'FeatureCollection',
          features: [
            {
              type: 'Feature',
              properties: { ...geofence },
              geometry: {
                type: 'Polygon',
                coordinates: [coordinates],
              },
            },
          ],
        },
      });
  
      // Add the actual geofence fill layer
      map.current.addLayer({
        id: `geofence-layer-${geofence.id}`,
        type: 'fill',
        source: sourceId,
        paint: {
          'fill-color': '#ff0000',
          'fill-opacity': 0.3,
        },
      });
  
      // Add the geofence outline
      map.current.addLayer({
        id: `geofence-outline-${geofence.id}`,
        type: 'line',
        source: sourceId,
        paint: {
          'line-color': '#ff0000',
          'line-width': 2,
        },
      });
  
      // Add an invisible clickable layer with a larger area
      map.current.addLayer({
        id: `geofence-click-area-${geofence.id}`,
        type: 'fill',
        source: sourceId,
        paint: {
          'fill-opacity': 0, // Invisible
        },
      });
  
      // Add click handler for the invisible clickable area
      map.current.on('click', `geofence-click-area-${geofence.id}`, (e) => {
        // Zoom in to the clicked geofence
        map.current.flyTo({
          center: [coordinates[0][0], coordinates[0][1]],
          zoom: 10, // Adjust zoom as needed
          essential: true,
        });
  
        // Set the selected geofence to display the overlay
        setSelectedGeofence(geofence);
      });
  
      // Add a marker at the first coordinate
      new maplibregl.Marker({ color: '#ff0000' })
        .setLngLat([coordinates[0][0], coordinates[0][1]]) // Use [longitude, latitude]
        .addTo(map.current);
    }
  };

  return (
    <div style={{ height: '100vh', position: 'relative' }}>
      <h1 style={{ position: 'absolute', zIndex: 1000, margin: '10px' }}>Add Warehouse</h1>
      <div
        ref={mapContainer}
        style={{ position: 'absolute', top: 0, bottom: 0, left: 0, right: 0 }}
      />
      <button
        style={{
          position: 'absolute',
          top: '20px',
          right: '20px',
          zIndex: 1000,
          backgroundColor: '#007bff',
          color: '#fff',
          border: 'none',
          padding: '10px 20px',
          borderRadius: '5px',
          cursor: 'pointer',
        }}
        onClick={() => {
          if (map.current) {
            map.current.easeTo({
              zoom: 5,
              center: [78.9629, 20.5937],
              duration: 1000,
            });
          }
        }}
      >
        Reset View
      </button>

      {selectedGeofence && (
        <WarehouseDetails
          geofence={selectedGeofence}
          onClose={() => setSelectedGeofence(null)}
        />
      )}
    </div>
  );
};

export default ViewWarehouse;
