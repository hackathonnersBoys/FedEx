import React, { useState } from 'react';

const ScannerPage = () => {
  const [parcelIds, setParcelIds] = useState([]);
  const [bagId, setBagId] = useState(null);
  const [truckId, setTruckId] = useState('');
  const [bagIds, setBagIds] = useState([]);
  const [scannedBarcode, setScannedBarcode] = useState('');
  const [message, setMessage] = useState(null);

  // Handle scanning of parcel barcodes
  const handleScanParcel = (e) => {
    e.preventDefault();

    if (!scannedBarcode.trim()) {
      setMessage({ type: 'error', text: 'Invalid barcode. Please try again.' });
      return;
    }

    setParcelIds([...parcelIds, scannedBarcode.trim()]);
    setScannedBarcode('');
    setMessage(null);
  };

  // Handle sending parcel IDs to create a bag
  const handleAllocateParcelsToBag = async () => {
    if (parcelIds.length === 0) {
      setMessage({ type: 'error', text: 'No parcels scanned. Please scan parcels first.' });
      return;
    }

    try {
      const response = await fetch('http://localhost:3000/api/setParcelToBag', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ parcel_ids: parcelIds }),
      });

      if (!response.ok) {
        throw new Error('Failed to allocate parcels to a bag.');
      }

      const data = await response.json();
      setBagId(data.bag_id); // Assuming the API returns the created bag ID
      setBagIds([...bagIds, data.bag_id]);
      setParcelIds([]); // Clear the parcel list
      setMessage({ type: 'success', text: `Bag created successfully with ID: ${data.bag_id}` });
    } catch (error) {
      console.error('Error allocating parcels to a bag:', error);
      setMessage({ type: 'error', text: 'Failed to allocate parcels to a bag. Please try again.' });
    }
  };

  // Handle allocating the bag to a truck
  const handleAllocateBagToTruck = async () => {
    if (!bagId || !truckId.trim()) {
      setMessage({ type: 'error', text: 'Please scan a bag and select a truck to allocate.' });
      return;
    }

    try {
      const response = await fetch('http://localhost:3000/api/setBagToTruck', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ bag_ids: [bagId], truck_id: truckId }),
      });

      if (!response.ok) {
        throw new Error('Failed to allocate bag to a truck.');
      }

      const data = await response.json();
      setMessage({ type: 'success', text: `Bag ID ${bagId} allocated to Truck ID: ${truckId}` });
      setBagId(null);
      setTruckId('');
    } catch (error) {
      console.error('Error allocating bag to truck:', error);
      setMessage({ type: 'error', text: 'Failed to allocate bag to a truck. Please try again.' });
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: 'auto' }}>
      <h1>Parcel Scanner</h1>
      {message && (
        <p
          style={{
            color: message.type === 'success' ? 'green' : 'red',
            fontWeight: 'bold',
          }}
        >
          {message.text}
        </p>
      )}
      {/* Scan Parcel */}
      <form onSubmit={handleScanParcel} style={{ marginBottom: '20px' }}>
        <label>
          <strong>Scan Parcel Barcode:</strong>
          <input
            type="text"
            value={scannedBarcode}
            onChange={(e) => setScannedBarcode(e.target.value)}
            required
            style={{ width: '100%', padding: '8px', marginTop: '5px' }}
          />
        </label>
        <button
          type="submit"
          style={{
            backgroundColor: '#007bff',
            color: '#fff',
            border: 'none',
            padding: '10px 15px',
            borderRadius: '5px',
            cursor: 'pointer',
            marginTop: '10px',
          }}
        >
          Add Parcel
        </button>
      </form>

      {/* Display Scanned Parcels */}
      {parcelIds.length > 0 && (
        <div style={{ marginBottom: '20px' }}>
          <h3>Scanned Parcels:</h3>
          <ul>
            {parcelIds.map((parcelId, index) => (
              <li key={index}>{parcelId}</li>
            ))}
          </ul>
          <button
            onClick={handleAllocateParcelsToBag}
            style={{
              backgroundColor: '#28a745',
              color: '#fff',
              border: 'none',
              padding: '10px 15px',
              borderRadius: '5px',
              cursor: 'pointer',
            }}
          >
            Allocate Parcels to Bag
          </button>
        </div>
      )}

      {/* Bag Allocation */}
      {bagIds.length > 0 && (
        <div style={{ marginBottom: '20px' }}>
          <h3>Scanned Bag ID: {bagId}</h3>
          <label>
            <strong>Truck ID:</strong>
            <input
              type="text"
              value={truckId}
              onChange={(e) => setTruckId(e.target.value)}
              required
              style={{ width: '100%', padding: '8px', marginTop: '5px' }}
            />
          </label>
          <button
            onClick={handleAllocateBagToTruck}
            style={{
              backgroundColor: '#ffc107',
              color: '#fff',
              border: 'none',
              padding: '10px 15px',
              borderRadius: '5px',
              cursor: 'pointer',
              marginTop: '10px',
            }}
          >
            Allocate Bag to Truck
          </button>
        </div>
      )}
    </div>
  );
};

export default ScannerPage;
