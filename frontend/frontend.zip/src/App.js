import React, { useContext, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom';
import WarehouseDashboard from './components/WarehouseDashboard ';

import ReportsPage from './components/ReportsPage';
import AdminDashboard from './components/AdminDashboard';
import AddTruck from './components/AddTruck';
import AddUser from './components/AddUser';
import AddWarehouse from './components/AddWarehouse';
import SchedulePage from './components/SchedulePage';
import ScannerPage from './components/ScannerPage';
import ViewWarehouse from './components/ViewWarehouse';
import PermissionsPage from './components/ManagePermissions';
import ManageCredentials from './components/ManageCredentials';
import LoginPage from './components/LoginPage';
// import { UserProvider, UserContext } from './UserContext'; // Import the context
import { UserProvider, UserContext  } from './components/UserContext';
const App = () => {
  return (
    <UserProvider>
      <MainApp />
    </UserProvider>
  );
};

const MainApp = () => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const { userRole, warehouseAccess } = useContext(UserContext);

  const toggleCollapse = () => {
    setIsCollapsed((prevState) => !prevState);
  };

  const navigationItems = {
    warehouse: [
      { path: '/warehouse-dashboard', label: 'Fleet', icon: '🚛' },
      { path: '/reports', label: 'Reports', icon: '📊' },
      { path: '/schedule', label: 'Schedule', icon: '⌚' },
      { path: '/add-user', label: 'Add User', icon: '👤' },
    ],
    admin: [
      { path: '/admin-dashboard', label: 'Admin Panel', icon: '🛠️' },
      { path: '/reports', label: 'Reports', icon: '📊' },
      { path: '/view-warehouse', label: 'View Warehouse', icon: '👁️' },
      { path: '/schedule', label: 'Schedule', icon: '⌚' },
      { path: '/add-truck', label: 'Add Truck', icon: '🚚' },
      { path: '/add-warehouse', label: 'Add Warehouse', icon: '🏢' },
      { path: '/add-user', label: 'Add User', icon: '👤' },
      { path: '/manage-permissions', label: 'Manage Permissions', icon: '📃' },
      { path: '/manage-credentials', label: 'Manage Credentials', icon: '🔒' },
    ],
    scanner: [
      { path: '/scanner-dashboard', label: 'Scanner Dashboard', icon: '🔍' },
    ],
  };

  const userNavItems = userRole ? navigationItems[userRole] : [];

  return (
    <Router>
      <div style={{ display: 'flex', height: '100vh' }}>
        {userRole && (
          <div
            style={{
              width: isCollapsed ? '60px' : '200px',
              backgroundColor: '#f4f4f4',
              padding: isCollapsed ? '10px 5px' : '20px',
              borderRight: '1px solid #ccc',
              display: 'flex',
              flexDirection: 'column',
              alignItems: isCollapsed ? 'center' : 'flex-start',
              transition: 'width 0.3s',
            }}
          >
            <button
              onClick={toggleCollapse}
              style={{
                backgroundColor: '#007bff',
                color: '#fff',
                border: 'none',
                padding: '5px 10px',
                cursor: 'pointer',
                marginBottom: '20px',
              }}
            >
              {isCollapsed ? '>' : '<'}
            </button>

            <ul style={{ listStyle: 'none', padding: 0, textAlign: isCollapsed ? 'center' : 'left' }}>
              {userNavItems.map((item) => (
                <li key={item.path} style={{ marginBottom: '10px' }}>
                  <Link
                    to={item.path}
                    style={{
                      textDecoration: 'none',
                      color: '#007bff',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: isCollapsed ? 'center' : 'flex-start',
                    }}
                  >
                    <span style={{ marginRight: isCollapsed ? '0' : '10px' }}>{item.icon}</span>
                    {!isCollapsed && item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        )}

        <div style={{ flex: 1 }}>
          <Routes>
            <Route path="/login" element={<LoginPage />} />

            {userRole ? (
              <>
                <Route path="/warehouse-dashboard" element={<WarehouseDashboard warehouseAccess={warehouseAccess} />} />
                <Route path="/reports" element={<ReportsPage />} />
                <Route path="/schedule" element={<SchedulePage />} />
                <Route path="/admin-dashboard" element={<AdminDashboard />} />
                <Route path="/add-truck" element={<AddTruck />} />
                <Route path="/add-warehouse" element={<AddWarehouse />} />
                <Route path="/view-warehouse" element={<ViewWarehouse warehouseAccess={warehouseAccess} />} />
                <Route path="/add-user" element={<AddUser />} />
                <Route path="/scanner-dashboard" element={<ScannerPage />} />
                <Route path="/manage-permissions" element={<PermissionsPage />} />
                <Route path="/manage-credentials" element={<ManageCredentials />} />
                <Route path="*" element={<Navigate to={userNavItems[0]?.path || '/'} />} />
              </>
            ) : (
              <Route path="*" element={<Navigate to="/login" />} />
            )}
          </Routes>
        </div>
      </div>
    </Router>
  );
};

export default App;
